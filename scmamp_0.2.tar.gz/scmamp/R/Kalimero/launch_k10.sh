##### Parametros #######
## No tiene

#$ -S /bin/bash
#
#######################################
# Usar el directorio de trabajo actual
#######################################
#$ -cwd

#$ -j y

###########################
# usar colas indicadas
###########################

#$ -q 2014all.q
#$ -t 1-1:1
#$ -o /dev/null

#################################
#Nuestro directorio de scratch
##################################
# scratch en kalimero, i2Bask y ATC
scrt=/var/tmp/$USER/$JOB_ID-$SGE_TASK_ID

#crear directorio scratch
#echo "mkdir -p $scrt"
mkdir -p $scrt

current_dir=`pwd`

#######################################################
#Copiamos los archivos al directorio scratch.
#Usaremos cp -r para copiar tambien subdirectorios.
#Se puede pasar un tercer parametro en el que indicar
#ficheros adicionales a copiar
#######################################################

cp exhaustive_sets_k10.R $scrt
cp exhaustive.sets.RData $scrt

#Nos movemos de directorio
cd $scrt

#########################
#Ejecutamos el programa
#########################

R_COMMAND=R
data=\'$1\'
group=\'$2\'
quantile=$3
B=$4

$R_COMMAND CMD BATCH --vanilla --quiet exhaustive_sets_k9.R

mkdir -p $current_dir/results

mv *.Rdata $current_dir/results
mv *.Rout $current_dir/results
cd $current_dir

rm -rf $scrt


