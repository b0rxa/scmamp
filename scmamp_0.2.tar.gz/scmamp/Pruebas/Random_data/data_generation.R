m <- 50
data_1 <- 0.5 + runif(m)/2
data_2 <- 0.33 + runif(m)/2

data <- cbind(paste("Database_" , 1:m , sep = ""), data_1 , data_2 , (data_1+data_2)/2 , data_2 + 0.1)
colnames(data) <- c("Dataset", "A1","A2","A12","A2+")

write.csv(data , file = "comp_50_4.csv", row.names=F)


m <- 150
data_1 <- 0.5 + runif(m)/2
data_2 <- 0.33 + runif(m)/2

data <- cbind(data_1 , data_2 , (data_1+data_2)/2 , data_2 + 0.1)
data <- cbind(data , data*(0.5 + runif(50)/2))

data <- cbind(paste("Database_" , 1:m , sep = "") , data)
colnames(data) <- c("Dataset", paste("Alg",1:8))

write.csv(data , file = "comp_150_8.csv", row.names=F)


m <- 150
data_1 <- 0.5 + runif(m)/2
data_2 <- 0.33 + runif(m)/2

data <- cbind(data_1 , data_2 , (data_1+data_2)/2 , data_2 + 0.1)
data <- cbind(data , data*(0.5 + runif(50)/2))

data <- cbind(paste("Database_" , 1:m , sep = "") , data , max(1,data_1*1.1))
colnames(data) <- c("Dataset", paste("Alg",1:9))

write.csv(data , file = "comp_150_9.csv", row.names=F)


data_kernels <- summarize.data(data , group.by = c('size','alpha','beta'))

set.name <- paste(paste("size=" , data_kernels[,"size"],sep="") , paste("alpha=" , data_kernels[,"alpha"],sep="") , 
                  paste("beta=" , data_kernels[,"beta"],sep="") , sep=";")

data_kernels <- cbind(set.name , data_kernels[,-(1:3)])
write.csv(data_kernels, file="kernels_test.csv")
