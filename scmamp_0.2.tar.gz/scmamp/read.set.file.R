parse.pair <- function(pair){
  sp <- unlist(strsplit(pair , ','))
  c(as.numeric(sp[1]) , as.numeric(sp[2]))
}

parse.set <- function(set){
  pairs <- unlist(strsplit(set , ';'))
  res <- sapply(pairs , parse.pair)
  colnames(res) <- NULL
  res
}


f <- file('./E9.set' , 'r')
lines <- readLines(f)
k9 <- lapply(lines , parse.set)


close(f)
