library("scma")

data1 <- matrix (runif(100*5),ncol = 5)
data2 <- matrix (runif(100*5),ncol = 5)
fact <- matrix(rep(runif(5)*0.5 , 100) , ncol=5)
data <- cbind(data1, data2*fact)
colnames(data) <- paste("Alg",1:dim(data)[2] , sep="_")

load("./data/garcia.herrera.RData")

res  <- scma(data.garcia.herrera)

y <- as.vector(data)
algs <- rep()
friedman.test(data)

N<-dim(data)[1]
k<-dim(data)[2]
stat <- 12*N/(k*(k+1))*(sum(res$mean.rank^2) - (k*(k+1)^2)/4)
stat

mr <- c(2.1,3.25,2.2,4.333,3.117)
sta.friedman <- 12*N/(k*(k+1))*(sum(mr^2) - (k*(k+1)^2)/4)
1-pchisq(sta.friedman , df = k-1)


## Iman Davenport correction of Friedman's test
stat.iman <- (N-1)*sta.friedman / (N*(k-1) - sta.friedman)
1-pf(stat.iman , df1 = (k-1) , df2 = (k-1)*(N-1))
friedman.test(data.garcia.herrera)


res <- scma(data.garcia.herrera)
plot.pvalues(res)
res$adj.pvalues




## Wicoxon
x<-data.garcia.herrera[,1]
y<-data.garcia.herrera[,2]
wilcox.test(x,y)$statistic

ranks <- rank.matrix(data.garcia.herrera[,1:2])
diff (colSums(ranks))

## Nemenyi
plot.cdd(data.garcia.herrera)


## Shaffer

## pvalues tabla 5 garcia y herrera
raw.pvalues <- c(0.0048 , 0.8065 , 4.487*10^-8 , 0.0128 , 0.0101 , 0.008 , 0.744 , 1.736*10^-7 , 0.0247 , 0.0029)
k<-5
pairs <- do.call(rbind,sapply(1:(k-1), FUN=function(x) cbind((x),(x+1):k)))
raw.matrix <- matrix(rep(NA , k^2),k)
raw.matrix[pairs] <- raw.pvalues
raw.matrix[pairs[,c(2,1)]] <- raw.pvalues


raw <- res$raw.pvalues[upper.tri(res$raw.pvalues)]
shaffer.static(raw,raw)
  



# Exhaustive set generation -----------------------------------------------

E <- list (k1=vector())
E$k2 <- exhaustive.sets(1:2)
E$k3 <- exhaustive.sets(1:3)
E$k4 <- exhaustive.sets(1:4)
E$k5 <- exhaustive.sets(1:5)
E$k6 <- exhaustive.sets(1:6)
E$k7 <- exhaustive.sets(1:7)
save(E,file="data/exhaustive.sets.1.to.7.Rd")
E$k8 <- exhaustive.sets(1:8)
save(E,file="data/exhaustive.sets.1.to.8.Rd")
E$k8 <- exhaustive.sets(1:9)
save(E,file="data/exhaustive.sets.1.to.9.Rd")

a1 <- aov(values ~ groups)
posthoc <- TukeyHSD(x=a1, 'groups', conf.level=0.95)


# Generation of result files ----------------------------------------------


library(bde)
reps <- 30
sizes <- c(10,50,100,500)
parameter.pairs <- list(c(1,5) , c(2,5) , c(5,5) , c(1,1))
algorithms <- c('vitale' , 'betakernel' , 'boundarykernel' , 'kakizawa')

experiment <- function(algorithm , sample , refdist){
  estimateddist <- bde(dataPoints = sample , dataPointsCache = refdist@dataPointsCache , estimator = algorithm)
  mise(refdist , estimateddist)
}


dir.exp <- "./loading_tests/experiment_files/"
dir.comp <- "./loading_tests/comparison_files/"
dir.parent <- "./loading_tests/"

global.data <- data.frame()
for (size in sizes){
  aux <- data.frame()
  for(param in parameter.pairs){
    problem.res <- data.frame()
    for(r in 1:reps){
      sample <- rbeta(size , param[1] , param[2])
      x <- seq(0 , 1 , length.out = 100)
      refdist <- boundedDensity (x = x , densities = dbeta(x , param[1] , param[2]))
      res.vector <- vector()
      for(algorithm in algorithms){
        res <- experiment(algorithm , sample , refdist)
        
        res.vector <- c (res.vector , res)
      }  
      names(res.vector) <- algorithms
      problem.res <- rbind(problem.res , res.vector)
      colnames(problem.res) <- algorithms
      sapply (1:length(algorithms) , FUN = function(i) write.csv(problem.res[,i] , row.names=FALSE , col.names = FALSE , file=paste(dir.exp , "beta_",param[1],",",param[2],"_size_",size,"_",algorithms[i],".out",sep="")))
      
      write.csv(problem.res , row.names=FALSE , file=paste(dir.comp , "beta_",param[1],",",param[2],"_size_",size,".out",sep=""))
    }
    aux <- rbind(aux , cbind(alpha = param[1] , beta = param[2] , problem.res))
  }
  global.data <- rbind(global.data , cbind(size=size , aux))
}

exp.data <- rbind(data.frame(global.data[,1:3] , algorithm = algorithms[1] , error = global.data[,4]), 
                  data.frame(global.data[,1:3] , algorithm = algorithms[2] , error = global.data[,5]), 
                  data.frame(global.data[,1:3] , algorithm = algorithms[3] , error = global.data[,6]), 
                  data.frame(global.data[,1:3] , algorithm = algorithms[4] , error = global.data[,7]))


write.csv(exp.data , row.names = FALSE , file = paste(dir.parent , "beta_complete_experiment.out",sep=""))
write.csv(global.data , row.names=FALSE , file=paste(dir.parent , "beta_complete_comparision.out",sep=""))


