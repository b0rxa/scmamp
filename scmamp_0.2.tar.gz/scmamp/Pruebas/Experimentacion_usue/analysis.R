library(scma)

analyze.results <- function (file.path , alpha = 0.05 , layout = "dot"){
	data <- read.csv(file.path)
	results <- data[,-1]
	
	ranks <- rank.matrix(results)
	mean.rank <- colMeans(ranks)
	
	cat("### Mean Ranks ###\n")
	cat("------------------\n\n")
	print(mean.rank)
	
	
	## CD plot
	x11(width=8,height=4)
	critical.difference.plot(results.matrix = results , alpha = alpha)
	
	## Friedmans test
	cat("### Friedman test ###\n")
	cat("-----------------------\n\n")
	fr.pval <- friedman.test(results)$p.value
	if (fr.pval < alpha) {
		cat("Null hypothesis in Friedman test rejected with p-value",fr.pval,"\n")
	}else{
		cat("Null hypothesis in Friedman test NOT rejected with p-value",fr.pval,"\n")
	}
		
	## Iman Davenport test
	cat("### Iman Davenport test ###\n")
	cat("-----------------------\n\n")
	id.pval <- iman.davenport.test(results)$p.value
	if (id.pval < alpha) {
		cat("Null hypothesis in Iman Davenport test rejected with p-value",id.pval,"\n")
	}else{
		cat("Null hypothesis in Iman Davenport test NOT rejected with p-value",id.pval,"\n")
	}
	
	## So far, dynamic approach only for 8 or less algorithms ...
	pwcomp.shaffer <- pairwise.test(results ,  correction = "Bergmann Hommel")
	
	
	k <- ncol(results)
	pairs <- do.call(rbind,sapply(1:(k-1), FUN=function(x) cbind((x),(x+1):k)))
	
	comparison.matrix <- data.frame (Comparison = paste(colnames(results)[pairs[,1]] , "vs." , colnames(results)[pairs[,2]]),
                                   ras = pwcomp.shaffer$raw.pvalues[pairs],
                                   corrected = pwcomp.shaffer$corrected.pvalues[pairs])
  
	o <- order(comparison.matrix[,2])
	comparison.matrix <- comparison.matrix[o,]
	colnames(comparison.matrix) <- c("Comparison" , "Raw p-value" , "Corrected p-values")
	
	x11(width=8, height=8)
	algorithm.graph(pwcomp.shaffer$corrected.pvalues , alpha = 0.05 , mean.value = mean.rank , layout)
	
	
	x11(width=10,height=5)
	g <-plot.pvalues(pwcomp.shaffer$corrected.pvalues , alg.order = order(mean.rank))
	print(g)
	
	comparison.matrix
}

comp.acc <- analyze.results ("./accuracy.csv" , alpha = 0.05 , layout = "circo")
## Garcia and Herrera's software generates last table (shaffer only)
write.tabular(comp.acc , format = 'E' , hrule = 0 , vrule = 1 , print.row.names = FALSE)


comp.ear <- analyze.results ("./earlyness.csv" , alpha = 0.05)
## Garcia and Herrera's software generates last table (Bergmann Hommel only)
write.tabular(comp.ear , format = 'E' , hrule = 0 , vrule = 1 , print.row.names = FALSE)
