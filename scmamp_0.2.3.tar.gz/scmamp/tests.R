# NO GROPUS, ALL VS ALL ---------------------------------------------------

k<-5
res <- postHocTest(data.gh.2008, test="wilcoxon", correct="bonferroni")
all(apply(res$raw.pval*(k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval, na.rm=TRUE)
res <- postHocTest(data.gh.2008, test="friedman", correct="bonferroni")
all(apply(res$raw.pval*(k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval, na.rm=TRUE)
res <- postHocTest(data.gh.2008, test="quade", correct="bonferroni")
all(apply(res$raw.pval*(k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval, na.rm=TRUE)


res <- postHocTest(data.gh.2008, test="quade", correct="finner")
all(res$corrected.pval==t(res$corrected.pval), na.rm=T)

res <- postHocTest(data.gh.2008, test="quade", correct="shaffer")
all(res$corrected.pval==t(res$corrected.pval), na.rm=T)

res <- postHocTest(data.gh.2008, test="quade", correct="bergmann")
all(res$corrected.pval==t(res$corrected.pval), na.rm=T)

res <- postHocTest(data.gh.2008, test="quade", correct="holland")
all(res$corrected.pval==t(res$corrected.pval), na.rm=T)

res <- postHocTest(data.gh.2008, test="quade", correct="rom")
all(res$corrected.pval==t(res$corrected.pval), na.rm=T)


k<-4
res <- postHocTest(data.gh.2010, test="wilcoxon", correct="bonferroni")
all(apply(res$raw.pval*(k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval, na.rm=TRUE)
res <- postHocTest(data.gh.2010, test="friedman", correct="bonferroni")
all(apply(res$raw.pval*(k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval, na.rm=TRUE)
res <- postHocTest(data.gh.2010, test="quade", correct="bonferroni")
all(apply(res$raw.pval*(k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval, na.rm=TRUE)


res <- postHocTest(data.gh.2010, test="quade", correct="finner")
all(res$corrected.pval==t(res$corrected.pval), na.rm=T)

res <- postHocTest(data.gh.2010, test="quade", correct="shaffer")
all(res$corrected.pval==t(res$corrected.pval), na.rm=T)

res <- postHocTest(data.gh.2010, test="quade", correct="bergmann")
all(res$corrected.pval==t(res$corrected.pval), na.rm=T)

res <- postHocTest(data.gh.2010, test="quade", correct="holland")
all(res$corrected.pval==t(res$corrected.pval), na.rm=T)

res <- postHocTest(data.gh.2010, test="quade", correct="rom")
all(res$corrected.pval==t(res$corrected.pval), na.rm=T)

# Check the names
res


# NO GROUPS, ALL VS CONTROL -----------------------------------------------

k<-5
res <- postHocTest(data.gh.2008, test="wilcoxon", correct="bonferroni", control=1)
all(res$raw.pval*(k-1) == res$corrected.pval, na.rm=TRUE)

res <- postHocTest(data.gh.2008, test="t-test", correct="bonferroni", control=1)
all(res$raw.pval*(k-1) == res$corrected.pval, na.rm=TRUE)

res <- postHocTest(data.gh.2008, test="aligned ranks", correct="bonferroni", control=1)
all(res$raw.pval*(k-1) == res$corrected.pval, na.rm=TRUE)


res <- postHocTest(data.gh.2008, test="aligned ranks", correct="finner", control=1)
res <- postHocTest(data.gh.2008, test="aligned ranks", correct="holland", control=1)
res <- postHocTest(data.gh.2008, test="aligned ranks", correct="rom", control=1)
res <- postHocTest(data.gh.2008, test="aligned ranks", correct="li", control=1)
# Should produce an error
res <- postHocTest(data.gh.2008, test="aligned ranks", correct="bergmann", control=1)
res <- postHocTest(data.gh.2008, test="aligned ranks", correct="shaffer", control=1)

# Check the names
res



# GROUPS, ALL VS. ALL -----------------------------------------------------

k <- 8
n <- 3
res <- postHocTest(data.blum.2015[,-2], group.by=1, test="wilcoxon", correct="bonferroni")
all(apply(res$raw.pval[,,1]*(n*k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval[,,1], na.rm=TRUE)
all(apply(res$raw.pval[,,2]*(n*k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval[,,2], na.rm=TRUE)
all(apply(res$raw.pval[,,3]*(n*k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval[,,3], na.rm=TRUE)

res <- postHocTest(data.blum.2015[,-2], group.by=1, test="friedman", correct="bonferroni")
all(apply(res$raw.pval[,,1]*(n*k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval[,,1], na.rm=TRUE)
all(apply(res$raw.pval[,,2]*(n*k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval[,,2], na.rm=TRUE)
all(apply(res$raw.pval[,,3]*(n*k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval[,,3], na.rm=TRUE)

res <- postHocTest(data.blum.2015[,-2], group.by=1, test="quade", correct="bonferroni")
all(apply(res$raw.pval[,,1]*(n*k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval[,,1], na.rm=TRUE)
all(apply(res$raw.pval[,,2]*(n*k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval[,,2], na.rm=TRUE)
all(apply(res$raw.pval[,,3]*(n*k*(k-1)/2), MARGIN=c(1,2), FUN=function(i) min(i,1)) == res$corrected.pval[,,3], na.rm=TRUE)


res <- postHocTest(data.blum.2015[,-2], group.by=1, test="wilcoxon", correct="rom")
all(res$corrected.pval[,,1]==t(res$corrected.pval[,,1]), na.rm=T)
all(res$corrected.pval[,,2]==t(res$corrected.pval[,,2]), na.rm=T)
all(res$corrected.pval[,,3]==t(res$corrected.pval[,,3]), na.rm=T)

res <- postHocTest(data.blum.2015[,-2], group.by=1, test="friedman", correct="holland")
all(res$corrected.pval[,,1]==t(res$corrected.pval[,,1]), na.rm=T)
all(res$corrected.pval[,,2]==t(res$corrected.pval[,,2]), na.rm=T)
all(res$corrected.pval[,,3]==t(res$corrected.pval[,,3]), na.rm=T)

res <- postHocTest(data.blum.2015[,-2], group.by=1, test="t-test", correct="finner")
all(res$corrected.pval[,,1]==t(res$corrected.pval[,,1]), na.rm=T)
all(res$corrected.pval[,,2]==t(res$corrected.pval[,,2]), na.rm=T)
all(res$corrected.pval[,,3]==t(res$corrected.pval[,,3]), na.rm=T)

# This should produce an error

res <- postHocTest(data.blum.2015[,-2], group.by=1, test="t-test", correct="shaffer")
res <- postHocTest(data.blum.2015[,-2], group.by=1, test="t-test", correct="bergmann")



# GROUPS, ALL VS CONTROL --------------------------------------------------


k <- 8
n <- 3
res <- postHocTest(data.blum.2015[,-2], group.by=1, test="wilcoxon", correct="bonferroni", control=2)
max((apply(res$raw.pval[,-1]*(k-1)*n, MARGIN=c(1,2), FUN=function(i) min(1, i)) - res$corrected.pval[,-1]), na.rm=TRUE)

res <- postHocTest(data.blum.2015[,-2], group.by=1, test="quade", correct="bonferroni", control=2)
max((apply(res$raw.pval[,-1]*(k-1)*n, MARGIN=c(1,2), FUN=function(i) min(1, i)) - res$corrected.pval[,-1]), na.rm=TRUE)

res <- postHocTest(data.blum.2015[,-2], group.by=1, test="aligned ranks", correct="bonferroni", control=2)
max((apply(res$raw.pval[,-1]*(k-1)*n, MARGIN=c(1,2), FUN=function(i) min(1, i)) - res$corrected.pval[,-1]), na.rm=TRUE)




