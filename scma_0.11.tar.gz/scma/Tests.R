library("scma")

data1 <- matrix (runif(100*5),ncol = 5)
data2 <- matrix (runif(100*5),ncol = 5)
fact <- matrix(rep(runif(5)*0.5 , 100) , ncol=5)
data <- cbind(data1, data2*fact)
colnames(data) <- paste("Alg",1:dim(data)[2] , sep="_")

load("./data/garcia.herrera.RData")

res  <- scma(data.garcia.herrera)

y <- as.vector(data)
algs <- rep()
friedman.test(data)

N<-dim(data)[1]
k<-dim(data)[2]
stat <- 12*N/(k*(k+1))*(sum(res$mean.rank^2) - (k*(k+1)^2)/4)
stat

mr <- c(2.1,3.25,2.2,4.333,3.117)
sta.friedman <- 12*N/(k*(k+1))*(sum(mr^2) - (k*(k+1)^2)/4)
1-pchisq(sta.friedman , df = k-1)


## Iman Davenport correction of Friedman's test
stat.iman <- (N-1)*sta.friedman / (N*(k-1) - sta.friedman)
1-pf(stat.iman , df1 = (k-1) , df2 = (k-1)*(N-1))
friedman.test(data.garcia.herrera)


res <- scma(data.garcia.herrera)
plot.pvalues(res)
res$adj.pvalues




## Wicoxon
x<-data.garcia.herrera[,1]
y<-data.garcia.herrera[,2]
wilcox.test(x,y)$statistic

ranks <- rank.matrix(data.garcia.herrera[,1:2])
diff (colSums(ranks))

## Nemenyi
plot.cdd(data.garcia.herrera)


## Shaffer

## pvalues tabla 5 garcia y herrera
raw.pvalues <- c(0.0048 , 0.8065 , 4.487*10^-8 , 0.0128 , 0.0101 , 0.008 , 0.744 , 1.736*10^-7 , 0.0247 , 0.0029)
k<-5
pairs <- do.call(rbind,sapply(1:(k-1), FUN=function(x) cbind((x),(x+1):k)))
raw.matrix <- matrix(rep(NA , k^2),k)
raw.matrix[pairs] <- raw.pvalues
raw.matrix[pairs[,c(2,1)]] <- raw.pvalues


raw <- res$raw.pvalues[upper.tri(res$raw.pvalues)]
shaffer.static(raw,raw)
  


## Generation of exhaustive sets
E <- list (k1=vector())
E$k2 <- exhaustive.sets(1:2)
E$k3 <- exhaustive.sets(1:3)
E$k4 <- exhaustive.sets(1:4)
E$k5 <- exhaustive.sets(1:5)
E$k6 <- exhaustive.sets(1:6)
E$k7 <- exhaustive.sets(1:7)
save(E,file="data/exhaustive.sets.1.to.7.Rd")
E$k8 <- exhaustive.sets(1:8)
save(E,file="data/exhaustive.sets.1.to.8.Rd")
E$k8 <- exhaustive.sets(1:9)
save(E,file="data/exhaustive.sets.1.to.9.Rd")




a1 <- aov(values ~ groups)
posthoc <- TukeyHSD(x=a1, 'groups', conf.level=0.95)
