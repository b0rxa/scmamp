library(scma)

data.all <- read.csv("kernels_test.csv")
data <- data.all[,-1]

## Average ranking
## vitale= 2.5; betakernel = 2.125; boundarykernel = 3.3125; kakizawa = 2.0625\\
mr <- colMeans(rank.matrix(data))
mr

## Friedman, stat=9.525, df=3, pvlue = 0.023066884305261937
friedman.test(data)

## Iman Davenport, stat=3.7134502923976607, df1=3, df2=45, pvlue = 0.018052998993327234
iman.davenport.test(data)

pw.ne <- pairwise.test(data , correction="Nemenyi")
pw.ho <- pairwise.test(data , correction="holm")
pw.sh <- pairwise.test(data , correction="Shaffer")
pw.bh <- pairwise.test(data , correction="Bergmann Hommel")

create.table <- function(mat){
	pa <- matrix(c(1,2,1,3,1,4,2,3,2,4,3,4),byrow=T , ncol=2)
	res <- cbind (paste(colnames(mat)[pa[,1]] , "vs" , colnames(mat)[pa[,2]]) , mat[pa])
	res[order(res[,2]),]
}

## all.vs.all, raw
## Raw: boundary vs kaki: 	0.0061699
## 		beta vs boundary:	0.0092768
## 		vitale vs boundary:	0.0750599
##		vitale vs kaki:		0.3378033
## 		vitale vs beta:		0.4113138
## 		beta vs kaki:		0.8910856

create.table(pw.ne$raw.pvalues)

## Nemenyi: boundary vs kaki: 	0.0370194
## 			beta vs boundary:	0.0556607
## 			vitale vs boundary:	0.4503592
##			vitale vs kaki:		1
## 			vitale vs beta:		1
## 			beta vs kaki:		1

create.table(pw.ne$corrected.pvalues)


## Holm: 	boundary vs kaki: 	0.0370194
## 			beta vs boundary:	0.0463839
## 			vitale vs boundary:	0.3002395
##			vitale vs kaki:		1
## 			vitale vs beta:		1
## 			beta vs kaki:		1

create.table(pw.ho$corrected.pvalues)

## Shaffer: boundary vs kaki: 	0.0370194
## 			beta vs boundary:	0.0370194
## 			vitale vs boundary:	0.2251796
##			vitale vs kaki:		1
## 			vitale vs beta:		1
## 			beta vs kaki:		1

create.table(pw.sh$corrected.pvalues)

## Berg-Hommel: boundary vs kaki: 	0.0370194
## 				beta vs boundary:	0.0370194
## 				vitale vs boundary:	0.1501197
##				vitale vs kaki:		1
## 				vitale vs beta:		1
## 				beta vs kaki:		1

create.table(pw.bh$corrected.pvalues)
