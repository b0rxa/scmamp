load("exhaustive.sets.RData")


## DO NOT USE ROXYGENIZE, IT IS NOT A PUBLIC FUNCTION!
# @title All the ordered subdivisions of a set
#
# @description This function is the base to crate all the partitions needed in the algorithm to create all the exhaustive sets in Figure 1, Garcia and Herrera (2008).
# @param set Set to be subdivided
# @return All the possible subdbisions of the set, including those where there are empty sets, but without repetitions. The format is a list of lists. Each element in the main list is a list containing two vectors, \code{s1} and \code{s2}, the two subsets of the set passed in the argument

subdivisions <- function (set){
  if (length(set)==1){ ## trivial case, only one posibility
    res <- list(list(s1=set, s2 = vector()))
  }else{## In the general case, subdivide the set without the last element and then add ...
    n <- length(set)
    last <- set[n]
    sb <- subdivisions (set[-n])
    ## ... the last element in all the first sets ...
    res <- lapply(sb , FUN = function (x) {list(s1=c(x$s1 , last) , s2=x$s2)})
    ## ... the last element in all the second sets ...
    res <- c(res , lapply(sb , FUN = function (x) {list(s1=x$s1 , s2=c(x$s2 , last))}))
    ## ... and finally the subdivision that has the last element alone in s2
    res <- c(res , list(list(s1=last , s2=set[-n])))
  }
  res
}

## DO NOT USE ROXYGENIZE, IT IS NOT A PUBLIC FUNCTION!
# @title Complete set of (non-empty) partitions of a set
#
# @description This function creates all the possible partitions indicated in the 6th step of the algorithm shown in Figure 1, Garcia and Herrera (2008).
# @param set Set to be partitioned
# @return All the possible partitions of the set where the last element is in the second subset and the first subset is not empty.

partition <- function (set){
  n <- length(set)
  if (n == 1){ ##In the trivial case it returns the only possible subdivision. This case violates the idea of having the last element in the last set, but it is the only exception and it does not pose a problema as the repetition of the set is under control.
    res <- subdivisions(set)
  }else{ ## In the general case, get all the subdivisions (which cannot have empty sets in the first subset) and add the last element at the end of each second subset.
    last <- set[n]
    sb <- subdivisions(set[-n])
    ## Add the last element only to the second subset (see Figur 1 in Garcia and Herrera, 2008)
    res <- lapply(sb , FUN = function (x) {list(s1=x$s1 , s2=c(x$s2 , last))})
  }
  res
}


## DO NOT USE ROXYGENIZE, IT IS NOT A PUBLIC FUNCTION!
# @title Remove repetitions in a list of subsets
#
# @description This function removes the repetitions in the result returned by the function \code{\link{exhaustive.sets}}
# @param E list of exhaustive sets
# @return The list without repetitions

merge.sets <- function (E1 , E2){
  already.in <- function (e){
    compare.with.e <- function (en){
      if (all(dim(en)==dim(e))) {
        return (all(en==e))
      }else{
        return (FALSE)
      }
    }    
    comparisons <- unlist(lapply (E2 , FUN = compare.with.e))
    any(comparisons)
  }
  
  ## Sequentially add partitions if they are not already in the solution
  bk<-lapply (E1 , FUN = function (x) if (!already.in (x)) E2 <<- c(E2 , list(x)))
  E2
}


#' @title Create the complet set of exhaustive sets
#'
#' @description This function implements the algorithm in Figure 1, Garcia and Herrera (2008) to create, given a set, the complete set of exhaustive sets E
#' @param set Set to create the exhaustive sets. The complexity of this algorithm is huge, so use with caution for sets of more than 7-8 elements.
#' @return A list with all the possible exhaustive sets, without repetitions
#' @examples
#' exhaustive.sets(c("A","B","C","D"))
exhaustive.sets <- function (set){
  k <- length(set)
  if (k<=length(E)){ ## Reuse the computed sets stored in the variable E
    E_l <- lapply(E[[k]] , FUN=function(x) matrix(set[x],nrow=2))
  }else{
    ## All possible pairwise comparisons, Garcia and Herrera, Table 1 steps 1-5
    if (k==1) return(NULL) ## No sense the set with one classifier
    if (k==2){ ## Base case, no lists
      E_l <- list(matrix(c(set[1],set[2]),ncol=1))
    }else{
      pairs <- do.call(rbind,sapply(1:(k-1), FUN=function(x) cbind((x),(x+1):k)))
      E_l <- list(apply (pairs , MARGIN = 1 , FUN = function(x) c(set[x[1]] , set[x[2]])))
    }
    ## Main loop
    if (length(set)>2){
      partitions <- partition(set)  ## Sets in step 6
      process.partition <- function (x){ ## Function to perform the main loop
        E1 <- exhaustive.sets (x$s1)
        E2 <- exhaustive.sets (x$s2)
        if (!is.null(E1)){
          E_l <<- merge.sets(E1 , E_l)
          if (!is.null(E2)){
            lapply (E1 , FUN = function(e1){
              E_l <<- merge.sets(lapply(E2 , FUN = function(e2) cbind(e1,e2)) , E_l)
            })
          }
        }      
        if (!is.null(E2)) E_l <<- merge.sets(E2 , E_l)
      }
      ## Do the loop (bk is just to avoid printing trash in the screen ...)
      bk <- lapply(partitions , FUN = process.partition)
    }
  }
  gc()
  E_l
}

# COMPUTE EXHAUSTIVE SET FOR K=9 ------------------------------------------

load("exhaustive.sets.RData")

system.time(k10 <- exhaustive.sets(1:10))
save("k10" , file = "./exhaustive_k10.Rdata")

